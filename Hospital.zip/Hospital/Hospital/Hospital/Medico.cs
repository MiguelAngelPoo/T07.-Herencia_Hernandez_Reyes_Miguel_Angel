﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    public class Medico:Persona
    {
        //encapsular
        public string cantidadDoc { get; set; }
        public string Edificio { get; set; }
    }
}
