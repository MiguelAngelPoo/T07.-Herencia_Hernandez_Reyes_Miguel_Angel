﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    public class Mujer:Persona
    {
        //encapsular
        public int id { get; set; }
        public string Tipo_sangre { get; set; }
    }
}
